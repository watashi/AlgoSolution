/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: acconfig.h,v 1.5 2004/01/15 01:19:14 grendel Exp $
*/

#undef HAVE_LIBFT2
#undef HAVE_FT_FT2BUILD
@TOP@
@BOTTOM@

/* Define if you have a declaration of ft_encoding_latin_1 */
#undef HAVE_DECL_FT_ENCODING_LATIN_1
