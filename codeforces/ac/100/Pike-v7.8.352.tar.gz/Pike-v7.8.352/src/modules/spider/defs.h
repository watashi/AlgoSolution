/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: defs.h,v 1.6 2002/10/11 01:39:55 nilsson Exp $
*/

extern void f_discdate(INT32 argc);
extern void f_stardate (INT32 args);
