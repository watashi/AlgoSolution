/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: acconfig.h,v 1.4 2003/08/08 12:27:30 nilsson Exp $
*/

#ifndef PIKE_MODULES_REGEXP_H
#define PIKE_MODULES_REGEXP_H

@TOP@

@BOTTOM@

#endif /* PIKE_MODULES_REGEXP_H */
