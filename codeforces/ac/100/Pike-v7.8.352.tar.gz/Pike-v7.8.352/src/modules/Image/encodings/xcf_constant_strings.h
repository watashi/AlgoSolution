/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: xcf_constant_strings.h,v 1.3 2002/10/11 01:39:45 nilsson Exp $
*/

STRING(bpp);
STRING(channels);
STRING(data);
STRING(height);
STRING(image_data);
STRING(layers);
STRING(mask);
STRING(name);
STRING(properties);
STRING(tiles);
STRING(type);
STRING(width);
