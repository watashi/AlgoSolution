/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: acconfig.h,v 1.5 2008/04/18 10:36:33 srb Exp $
*/

#ifndef PIPE_MACHINE_H
#define PIPE_MACHINE_H

@TOP@
@BOTTOM@

#endif
