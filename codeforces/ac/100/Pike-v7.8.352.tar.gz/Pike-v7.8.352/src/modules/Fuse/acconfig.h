/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: acconfig.h,v 1.1 2005/04/29 14:01:20 per Exp $
*/

/* Define if you have FUSE */
#undef HAVE_LIBFUSE
