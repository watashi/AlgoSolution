/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: version.h,v 1.5 2002/10/11 01:39:48 nilsson Exp $
*/

/*
 * This file is provided for CVS's sake, and to define a simple string to be
 * used as the module's release version
 */

#define PGSQL_VERSION "Postgres/1.0.2"
