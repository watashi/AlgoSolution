/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: acconfig.h,v 1.8 2002/10/11 01:39:59 nilsson Exp $
*/

#undef FUNCPROTO
#undef HAVE_GNOME
#undef HAVE_DPMS
#undef HAVE_GTK_20
#undef PGTK_AUTO_UTF8
