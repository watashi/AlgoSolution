/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: hsize.h,v 1.4 2004/04/11 18:51:10 per Exp $
*/

#define HSIZE 10007
