/*
 * $Id: circular_list.h,v 1.1 2003/09/10 15:19:09 mast Exp $
 */

void pike_init_CircularList_module(void);
void pike_exit_CircularList_module(void);

