/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: main.h,v 1.29 2005/11/23 15:07:57 grubba Exp $
*/

#ifndef MAIN_H
#define MAIN_H

/* Prototypes begin here */
int main(int argc, char **argv);
/* Prototypes end here */

#endif /* !MAIN_H */
