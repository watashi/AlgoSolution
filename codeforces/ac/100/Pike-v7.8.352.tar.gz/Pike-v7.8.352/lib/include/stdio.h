#if __VERSION__ > 7.6
#warning stdio.h is deprecated.
#endif
import Stdio;
