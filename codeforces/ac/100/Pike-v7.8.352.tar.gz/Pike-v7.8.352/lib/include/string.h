#if __VERSION__ > 7.6
#warning string.h is deprecated.
#endif
import String;
