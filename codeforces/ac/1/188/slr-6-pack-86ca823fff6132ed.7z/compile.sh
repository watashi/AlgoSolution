g++ -O2 -o roco roco.cpp
